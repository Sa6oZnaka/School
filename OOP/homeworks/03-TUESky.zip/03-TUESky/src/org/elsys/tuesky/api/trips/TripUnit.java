package org.elsys.tuesky.api.trips;

import java.time.Duration;

public interface TripUnit {

    Duration getDuration();

}
