package org.elsys.tuesky.api;

public class TUESkyException extends RuntimeException {
}
